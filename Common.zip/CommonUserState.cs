namespace Common;

public enum Size
{
    HeaderSize = 4,
}