namespace Common;

public enum RockPaper
{
    None = 0,
    SCISSORS = 1,
    ROCK = 2,
    PAPER = 3,
    
    //대결에 대한 결과 값 
    WIN = 10,
    LOOSE = 11,
    DREW = 12,
}
public enum RoomNumber
{
    NEW_ROOM = -1,
}